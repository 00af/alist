Security issues should be reported directly to me to remdex@gmail.com or info@livehelperchat.com. You can also just ping me on discord server https://discord.gg/YsZXQVh
