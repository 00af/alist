ace.define("ace/snippets/ini",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="ini"});                (function() {
                    ace.require(["ace/snippets/ini"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            